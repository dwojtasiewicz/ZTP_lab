package com.example.demo.dashboard;
import com.example.demo.entity.Book;
import com.example.demo.exception.MyError;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DashboardService {
    public  List<Book> books= new ArrayList();;

    public DashboardService() {
        books.add(new Book("book1", "author1", 123));
        books.add(new Book("book2", "author2", 234));
        books.add(new Book("book3", "author3", 345));
    }

    public List<Book> getBooks() {
        return books;
    }

    public Book getBook(String id) {
        for(int i = 0; i < books.size(); i++){
            if(books.get(i).getId() == id){
                return books.get(i);
            }
        }

        return null;
    }

    public void addBook(Book book) {
            this.books.add(book);
    }


    public Book removeBook(String id) throws MyError {
        for(int i = 0; i < books.size(); i++){
            if(books.get(i).getId() == id){
                Book temp = books.get(i);
                books.remove(i);
                return temp;
            }
        }
        return null;
    }

}