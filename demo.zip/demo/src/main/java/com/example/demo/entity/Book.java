package com.example.demo.entity;

import java.util.Date;
import java.util.Objects;
import java.util.UUID;

public class Book {
    private String id;
    private String title;
    private String author;
    private int publishedAt;

    public Book(String title, String author, int publishedAt) {
        id = UUID.randomUUID().toString();

        this.title = title;
        this.author = author;
        this.publishedAt = publishedAt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPublishedAt() {
        return publishedAt;
    }

    public void setPublishedAt(int publishedAt) {
        this.publishedAt = publishedAt;
    }

    @Override
    public String toString(){
        return title + " " + author + " (" + Integer.toString(publishedAt) + ")";
    }


    public String getId() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book)) return false;
        Book book = (Book) o;
        return getId().equals(book.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
