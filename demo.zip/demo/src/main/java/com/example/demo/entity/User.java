package com.example.demo.entity;

import java.util.Objects;
import java.util.UUID;

public class User {
    private String id;
    private String username;
    private String password;
    private Role role;

    public User() {
        id = UUID.randomUUID().toString();
    }

    public User(String username, String password) {
        id = UUID.randomUUID().toString();
        setUsername(username);
        setPassword(password);
        setRole(Role.ROLE_USER);
    }

    public User(String username, String password, Role role) {
        id = UUID.randomUUID().toString();
        setUsername(username);
        setPassword(password);
        setRole(role);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() { return id; }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

}
