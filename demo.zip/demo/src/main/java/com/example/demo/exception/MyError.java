package com.example.demo.exception;

public class MyError extends Exception {
    private String type;

    public MyError(String type, String message) {
        super(message);
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
