package com.example.demo.dashboard;

import com.example.demo.entity.Book;
import com.example.demo.exception.MyError;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;


@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    private DashboardService dashboardService= new DashboardService();

    @GetMapping(produces = "application/json")
    public List<Book> getBooks() {

        return dashboardService.getBooks();
    }

    @GetMapping(value = "/{id}", produces = "application/json")
    public Book getBook(@PathVariable String id) {
        return dashboardService.getBook(id);
    }

    @PostMapping(produces = "application/json")
    public List<Book> addNewBook(@RequestBody HashMap<String, String> newBook) {
        if(newBook.containsKey("title") && newBook.containsKey("author") && newBook.containsKey("publishedAt")) {
            String title = newBook.get("title");
            String author = newBook.get("author");
            int year = Integer.parseInt(newBook.get("publishedAt"));

            dashboardService.addBook(new Book(title, author, year));

            return dashboardService.getBooks();
        }
        else
        {
            return null;
        }
    }

    @DeleteMapping(value = "/{id}", produces = "application/json")
    public Book removeBook(@PathVariable String id) throws MyError {
       return dashboardService.removeBook(id);
    }

}