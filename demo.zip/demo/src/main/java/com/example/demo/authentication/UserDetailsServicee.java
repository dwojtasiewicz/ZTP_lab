package com.example.demo.authentication;
import com.example.demo.entity.User;
import com.example.demo.exception.MyError;
import com.example.demo.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class UserDetailsServicee implements UserDetailsService {

    private final UserService userService=new UserService();

    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
        try {
            User user = userService.getUserByLogin(login);
            return new UserDetailsss(user.getUsername(), user.getPassword(), user.getRole());
        } catch(Exception ex){
            throw new UsernameNotFoundException("Not found");
        }
    }
}
