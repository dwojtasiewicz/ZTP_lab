package com.example.demo.user;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.exception.MyError;
import org.springframework.stereotype.Service;
import java.util.HashMap;

@Service
public class UserService {

    HashMap<String,User> userSource = new HashMap<>();

    public void addUser(String username , String password , Role rola)
    {
        User newUser = new User( username, password,rola);
        userSource.put(username,newUser);
    }

    public UserService() {
        userSource.put("admin", new User( "admin", "admin",Role.ROLE_ADMIN));
    }

    public User getUserByLogin(String username) throws MyError {
        if (!userSource.containsKey(username)) {
            throw new MyError("SERVICE::USER_SERVICE::USER_NOT_FOUND", "User has not been found in users Map");
        }

        return userSource.get(username);
    }


}